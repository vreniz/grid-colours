/**
* Sabores de la Noche – main.js
* Handles: hamburger menu, smooth nav links, header scroll state
*/
/* ---------------------------------------------------------------
Hamburger Menu Toggle
--------------------------------------------------------------- */
const hamburgerBtn = document.getElementById('hamburger-btn');
const mobileMenu = document.getElementById('mobile-menu');
const mobileLinks = document.querySelectorAll('.mobile-link');
function openMenu() {
hamburgerBtn.classList.add('is-active');
mobileMenu.classList.add('is-open');
hamburgerBtn.setAttribute('aria-expanded', 'true');
mobileMenu.setAttribute('aria-hidden', 'false');
document.body.style.overflow = 'hidden';
}
function closeMenu() {
hamburgerBtn.classList.remove('is-active');
mobileMenu.classList.remove('is-open');
hamburgerBtn.setAttribute('aria-expanded', 'false');
mobileMenu.setAttribute('aria-hidden', 'true');
document.body.style.overflow = '';
}
hamburgerBtn.addEventListener('click', () => {
const isOpen = mobileMenu.classList.contains('is-open');
isOpen ? closeMenu() : openMenu();
});
// Close menu when a mobile nav link is clicked
mobileLinks.forEach(link => {
link.addEventListener('click', closeMenu);
});
// Close menu on Escape key
document.addEventListener('keydown', (e) => {
if (e.key === 'Escape') closeMenu();
});
/* ---------------------------------------------------------------

Header Scroll State (add shadow when scrolled)
--------------------------------------------------------------- */
const siteHeader = document.querySelector('.site-header');
function updateHeader() {
if (window.scrollY > 20) {
siteHeader.style.boxShadow = '0 4px 40px rgba(0,0,0,0.5)';
} else {
siteHeader.style.boxShadow = 'none';
}
}
window.addEventListener('scroll', updateHeader, { passive: true });
updateHeader(); // Run once on load
/* ---------------------------------------------------------------
Active Nav Link Highlight on Scroll
--------------------------------------------------------------- */
const sections = document.querySelectorAll('main section[id], footer[id]');
const navLinks = document.querySelectorAll('.nav-desktop a[href^="#"]');
const observer = new IntersectionObserver(
(entries) => {
entries.forEach(entry => {
if (entry.isIntersecting) {
const id = entry.target.getAttribute('id');
navLinks.forEach(link => {
link.classList.toggle(
'is-active',
link.getAttribute('href') === `#${id}`
);
});
}
});
},
{ rootMargin: '-30% 0px -60% 0px' }
);
sections.forEach(section => observer.observe(section));
/* ---------------------------------------------------------------
Newsletter form – simple UX feedback
--------------------------------------------------------------- */
const newsletterBtn = document.querySelector('.btn-newsletter');
const newsletterInput = document.getElementById('newsletter-email');
if (newsletterBtn && newsletterInput) {

newsletterBtn.addEventListener('click', () => {
const email = newsletterInput.value.trim();
if (!email || !email.includes('@')) {
newsletterInput.style.borderColor = 'var(--rose)';
newsletterInput.focus();
return;
}
newsletterInput.style.borderColor = 'var(--teal)';
newsletterBtn.textContent = 'Subscribed ✓';
newsletterBtn.disabled = true;
newsletterInput.value = '';
setTimeout(() => {
newsletterBtn.textContent = 'Subscribe';
newsletterBtn.disabled = false;
newsletterInput.style.borderColor = '';
}, 4000);
});
}